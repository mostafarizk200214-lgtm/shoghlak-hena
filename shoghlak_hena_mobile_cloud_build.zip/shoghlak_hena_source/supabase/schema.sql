-- Shoghlak Hena MVP database schema (Supabase / PostgreSQL)
-- Review and run in a new Supabase project. Enable RLS before production.

create extension if not exists pgcrypto;

create type public.account_role as enum ('job_seeker', 'employer', 'service_provider');
create type public.listing_kind as enum ('job', 'daily_work', 'service');
create type public.listing_status as enum ('pending', 'published', 'rejected', 'closed');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  role public.account_role not null,
  area text not null default 'المنصورة',
  bio text,
  skills text[] not null default '{}',
  avatar_url text,
  created_at timestamptz not null default now()
);

create table public.companies (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  description text,
  phone text,
  whatsapp text,
  address text,
  verified boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.listings (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  company_id uuid references public.companies(id) on delete set null,
  kind public.listing_kind not null,
  title text not null,
  description text not null,
  category text,
  area text not null default 'المنصورة',
  salary_text text,
  work_type text,
  contact_phone text,
  whatsapp text,
  status public.listing_status not null default 'pending',
  created_at timestamptz not null default now(),
  expires_at timestamptz
);

create table public.applications (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  applicant_id uuid not null references public.profiles(id) on delete cascade,
  message text,
  status text not null default 'submitted',
  created_at timestamptz not null default now(),
  unique(listing_id, applicant_id)
);

create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid references public.listings(id) on delete set null,
  participant_one uuid not null references public.profiles(id) on delete cascade,
  participant_two uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  check (participant_one <> participant_two)
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now(),
  read_at timestamptz
);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  reviewer_id uuid not null references public.profiles(id) on delete cascade,
  reviewed_id uuid not null references public.profiles(id) on delete cascade,
  listing_id uuid references public.listings(id) on delete set null,
  rating int not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz not null default now(),
  check (reviewer_id <> reviewed_id)
);

create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  listing_id uuid references public.listings(id) on delete cascade,
  reported_user_id uuid references public.profiles(id) on delete cascade,
  reason text not null,
  details text,
  status text not null default 'open',
  created_at timestamptz not null default now()
);

create index listings_area_status_idx on public.listings(area, status, created_at desc);
create index listings_owner_idx on public.listings(owner_id);
create index applications_applicant_idx on public.applications(applicant_id);
create index messages_conversation_idx on public.messages(conversation_id, created_at);

-- Row Level Security: starter policies. Add stricter admin policies before production.
alter table public.profiles enable row level security;
alter table public.companies enable row level security;
alter table public.listings enable row level security;
alter table public.applications enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.reviews enable row level security;
alter table public.reports enable row level security;

create policy "Profiles are readable by signed-in users"
on public.profiles for select to authenticated using (true);
create policy "Users create own profile"
on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "Users update own profile"
on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create policy "Published listings are visible"
on public.listings for select to anon, authenticated
using (status = 'published' or owner_id = auth.uid());
create policy "Owners create listings"
on public.listings for insert to authenticated
with check (owner_id = auth.uid());
create policy "Owners update own listings"
on public.listings for update to authenticated
using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy "Applicants view own applications"
on public.applications for select to authenticated
using (applicant_id = auth.uid() or exists (
  select 1 from public.listings l where l.id = listing_id and l.owner_id = auth.uid()
));
create policy "Users apply as themselves"
on public.applications for insert to authenticated
with check (applicant_id = auth.uid());

create policy "Conversation participants can view"
on public.conversations for select to authenticated
using (participant_one = auth.uid() or participant_two = auth.uid());
create policy "Conversation participants can read messages"
on public.messages for select to authenticated
using (exists (
  select 1 from public.conversations c where c.id = conversation_id
  and (c.participant_one = auth.uid() or c.participant_two = auth.uid())
));
create policy "Participants send messages"
on public.messages for insert to authenticated
with check (sender_id = auth.uid() and exists (
  select 1 from public.conversations c where c.id = conversation_id
  and (c.participant_one = auth.uid() or c.participant_two = auth.uid())
));

create policy "Reviews are publicly readable"
on public.reviews for select to anon, authenticated using (true);
create policy "Users create own reviews"
on public.reviews for insert to authenticated with check (reviewer_id = auth.uid());

create policy "Users create reports"
on public.reports for insert to authenticated with check (reporter_id = auth.uid());
create policy "Users view own reports"
on public.reports for select to authenticated using (reporter_id = auth.uid());

-- IMPORTANT:
-- 1) Add an admin role and admin-only moderation policies before public launch.
-- 2) Do not expose the Supabase service_role key in the mobile app.
-- 3) Add phone OTP, storage policies, rate limits, and abuse prevention before launch.
