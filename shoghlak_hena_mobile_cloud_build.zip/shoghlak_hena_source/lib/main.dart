import 'package:flutter/material.dart';

void main() {
  runApp(const ShoghlakHenaApp());
}

const brandGreen = Color(0xFF087F5B);
const paleGreen = Color(0xFFEAF5EF);

class ShoghlakHenaApp extends StatelessWidget {
  const ShoghlakHenaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'شُغلك هنا',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: brandGreen),
        scaffoldBackgroundColor: const Color(0xFFF8FAF9),
        fontFamily: 'Arial',
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Color(0xFF182B25),
          centerTitle: false,
          elevation: 0,
        ),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: WelcomeScreen(),
      ),
    );
  }
}

enum UserRole { jobSeeker, employer, serviceProvider }

extension UserRoleLabel on UserRole {
  String get label {
    switch (this) {
      case UserRole.jobSeeker:
        return 'باحث عن عمل';
      case UserRole.employer:
        return 'صاحب عمل';
      case UserRole.serviceProvider:
        return 'مقدم خدمة';
    }
  }

  String get description {
    switch (this) {
      case UserRole.jobSeeker:
        return 'ابحث عن وظيفة وقدّم بسهولة';
      case UserRole.employer:
        return 'انشر وظائف واستقبل المتقدمين';
      case UserRole.serviceProvider:
        return 'اعرض مهاراتك واستقبل العملاء';
    }
  }

  IconData get icon {
    switch (this) {
      case UserRole.jobSeeker:
        return Icons.badge_outlined;
      case UserRole.employer:
        return Icons.storefront_outlined;
      case UserRole.serviceProvider:
        return Icons.handyman_outlined;
    }
  }
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(),
              Container(
                width: 92,
                height: 92,
                decoration: BoxDecoration(
                  color: paleGreen,
                  borderRadius: BorderRadius.circular(28),
                ),
                child: const Icon(Icons.work_outline, size: 48, color: brandGreen),
              ),
              const SizedBox(height: 22),
              const Text(
                'شُغلك هنا',
                style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: brandGreen),
              ),
              const SizedBox(height: 8),
              const Text(
                'فرصتك أقرب مما تتخيل',
                style: TextStyle(fontSize: 17, color: Colors.black54),
              ),
              const SizedBox(height: 34),
              const Text(
                'اختار نوع حسابك',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 14),
              ...UserRole.values.map(
                (role) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Card(
                    elevation: 0,
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                      side: const BorderSide(color: Color(0xFFE5ECE8)),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      leading: CircleAvatar(
                        backgroundColor: paleGreen,
                        child: Icon(role.icon, color: brandGreen),
                      ),
                      title: Text(role.label, style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text(role.description),
                      trailing: const Icon(Icons.arrow_back_ios_new, size: 16),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => HomeScreen(role: role)),
                      ),
                    ),
                  ),
                ),
              ),
              const Spacer(),
              const Text(
                'النسخة التجريبية الأولى — المنصورة',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black45, fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class Job {
  final String title;
  final String company;
  final String area;
  final String salary;
  final String type;

  const Job(this.title, this.company, this.area, this.salary, this.type);
}

const sampleJobs = <Job>[
  Job('موظف مبيعات', 'شركة تجارية', 'حي الجامعة - المنصورة', 'حسب الاتفاق', 'دوام كامل'),
  Job('مطلوب دليفري', 'مطعم محلي', 'شارع الجمهورية - المنصورة', 'راتب + حوافز', 'دوام كامل'),
  Job('مساعد شيف', 'مطعم', 'المشاية - المنصورة', 'يحدد بالمقابلة', 'دوام جزئي'),
];

class HomeScreen extends StatefulWidget {
  final UserRole role;
  const HomeScreen({super.key, required this.role});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedIndex = 0;
  String search = '';

  @override
  Widget build(BuildContext context) {
    final pages = [
      _homeContent(),
      const Center(child: Text('المفضلة — ستُفعّل عند ربط قاعدة البيانات')),
      const Center(child: Text('المحادثات — ستُفعّل عند ربط قاعدة البيانات')),
      const Center(child: Text('الملف الشخصي — ستُفعّل عند التسجيل')),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('شُغلك هنا', style: TextStyle(fontWeight: FontWeight.w900, color: brandGreen)),
        actions: [
          IconButton(
            onPressed: () => _message('الإشعارات ستظهر بعد ربط الخدمة'),
            icon: const Icon(Icons.notifications_none),
          ),
        ],
      ),
      body: pages[selectedIndex],
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: brandGreen,
        foregroundColor: Colors.white,
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => CreateListingScreen(role: widget.role)),
        ),
        icon: const Icon(Icons.add),
        label: const Text('أضف إعلان'),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (value) => setState(() => selectedIndex = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.favorite_border), label: 'المفضلة'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'الرسائل'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    );
  }

  Widget _homeContent() {
    final filtered = sampleJobs.where((job) {
      final q = search.trim();
      return q.isEmpty || '${job.title} ${job.company} ${job.area}'.contains(q);
    }).toList();

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: paleGreen, borderRadius: BorderRadius.circular(22)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('أهلاً بيك 👋', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              const Text('دور على شغلك أو اعرض خدماتك في المنصورة'),
              const SizedBox(height: 16),
              TextField(
                onChanged: (value) => setState(() => search = value),
                decoration: InputDecoration(
                  hintText: 'بتدور على شغل إيه؟',
                  prefixIcon: const Icon(Icons.search),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 8),
              const Row(
                children: [
                  Icon(Icons.location_on_outlined, size: 17, color: brandGreen),
                  SizedBox(width: 4),
                  Text('المنصورة، الدقهلية', style: TextStyle(color: brandGreen, fontWeight: FontWeight.w600)),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const Text('الأقسام الرئيسية', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        GridView.count(
          crossAxisCount: 3,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.05,
          children: const [
            CategoryTile('وظائف', Icons.work_outline),
            CategoryTile('عمالة يومية', Icons.engineering_outlined),
            CategoryTile('حرف ومهن', Icons.handyman_outlined),
            CategoryTile('سائقين', Icons.local_shipping_outlined),
            CategoryTile('خدمات', Icons.home_repair_service_outlined),
            CategoryTile('شركات ومحلات', Icons.storefront_outlined),
          ],
        ),
        const SizedBox(height: 22),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('أحدث فرص العمل', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            Text('${filtered.length} فرص', style: const TextStyle(color: brandGreen)),
          ],
        ),
        const SizedBox(height: 10),
        if (filtered.isEmpty)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Text('مفيش نتائج مطابقة للبحث حالياً', textAlign: TextAlign.center),
          )
        else
          ...filtered.map((job) => JobCard(job: job)),
      ],
    );
  }

  void _message(String value) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  }
}

class CategoryTile extends StatelessWidget {
  final String title;
  final IconData icon;
  const CategoryTile(this.title, this.icon, {super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE8EEEA))),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: brandGreen, size: 29),
          const SizedBox(height: 8),
          Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
        ],
      ),
    );
  }
}

class JobCard extends StatelessWidget {
  final Job job;
  const JobCard({super.key, required this.job});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17), side: const BorderSide(color: Color(0xFFE8EEEA))),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(backgroundColor: paleGreen, child: const Icon(Icons.business_outlined, color: brandGreen)),
                const SizedBox(width: 10),
                Expanded(child: Text(job.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
                const Icon(Icons.bookmark_border, color: brandGreen),
              ],
            ),
            const SizedBox(height: 9),
            Text(job.company, style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 7),
            Row(
              children: [
                const Icon(Icons.location_on_outlined, size: 16, color: Colors.black45),
                const SizedBox(width: 4),
                Expanded(child: Text(job.area, style: const TextStyle(fontSize: 12, color: Colors.black54))),
              ],
            ),
            const SizedBox(height: 10),
            Wrap(spacing: 8, children: [
              _tag(job.type),
              _tag('الراتب: ${job.salary}'),
            ]),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('التقديم سيتاح بعد ربط الحسابات وقاعدة البيانات'))),
                child: const Text('عرض التفاصيل والتقديم'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tag(String value) => Chip(
    label: Text(value, style: const TextStyle(fontSize: 11)),
    backgroundColor: paleGreen,
    side: BorderSide.none,
    visualDensity: VisualDensity.compact,
  );
}

class CreateListingScreen extends StatefulWidget {
  final UserRole role;
  const CreateListingScreen({super.key, required this.role});

  @override
  State<CreateListingScreen> createState() => _CreateListingScreenState();
}

class _CreateListingScreenState extends State<CreateListingScreen> {
  final titleController = TextEditingController();
  final descriptionController = TextEditingController();
  final areaController = TextEditingController(text: 'المنصورة');
  final salaryController = TextEditingController();

  @override
  void dispose() {
    titleController.dispose();
    descriptionController.dispose();
    areaController.dispose();
    salaryController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isService = widget.role == UserRole.serviceProvider;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(isService ? 'إضافة خدمة' : 'إضافة وظيفة')),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Text(isService ? 'اعرض خدمتك للناس في المنصورة' : 'انشر فرصة عمل جديدة مجاناً', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 18),
            _field(titleController, isService ? 'اسم الخدمة أو المهنة' : 'المسمى الوظيفي'),
            _field(descriptionController, 'وصف الإعلان', maxLines: 4),
            _field(areaController, 'المنطقة'),
            _field(salaryController, isService ? 'سعر الخدمة (اختياري)' : 'الراتب (اختياري)'),
            const SizedBox(height: 18),
            FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: brandGreen, padding: const EdgeInsets.all(15)),
              onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('واجهة الإضافة جاهزة. حفظ الإعلان يحتاج إعداد قاعدة البيانات وتسجيل الدخول.')),
              ),
              icon: const Icon(Icons.publish),
              label: const Text('نشر الإعلان مجاناً'),
            ),
            const SizedBox(height: 10),
            const Text('سيخضع الإعلان للمراجعة قبل ظهوره للمستخدمين.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, fontSize: 12)),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController controller, String label, {int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
    );
  }
}
